stegosaurus = imread('stegosaurus.jpg');
stego = imread('stego.jpg');
stegosaurus = double(stegosaurus);
stego = double(stego-1);
stegano = (stegosaurus/1000.+stego)/3.;
stegano = mod(stegano*3,1);
imshow(stegano*3);
imwrite(stegano*3,'image.jpg');